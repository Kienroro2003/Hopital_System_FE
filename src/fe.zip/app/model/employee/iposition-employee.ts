export interface IPositionEmployee {
  positionId?: number;
  positionName?: string;
  positionFlag?: boolean;
}
