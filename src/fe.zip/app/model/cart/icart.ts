export interface ICart {
  cartId?: number;
  cartCode?: string;
  cartQuantity?: number;
  cartDateCreate?: string;
  cartTotalMoney?: number;
}
