export interface ICustomerType {
  customerTypeId?: number;
  customerTypeName?: string;
  customerTypeFlag?: boolean;
}
