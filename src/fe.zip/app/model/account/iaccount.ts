export interface IAccount {
  accountId?: number;
  username?: string;
  password?: string;
  accountFlag?: boolean;
}
