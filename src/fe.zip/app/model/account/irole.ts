export interface IRole {
  roleId?: number;
  roleName?: string;
  roleFlag?: boolean;
}
