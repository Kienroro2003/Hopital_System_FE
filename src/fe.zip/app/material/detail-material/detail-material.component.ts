import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-detail-material',
  templateUrl: './detail-material.component.html',
  styleUrls: ['./detail-material.component.css']
})
export class DetailMaterialComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
