import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-list-material',
  templateUrl: './list-material.component.html',
  styleUrls: ['./list-material.component.css']
})
export class ListMaterialComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
