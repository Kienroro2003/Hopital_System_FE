import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-material',
  templateUrl: './edit-material.component.html',
  styleUrls: ['./edit-material.component.css']
})
export class EditMaterialComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
