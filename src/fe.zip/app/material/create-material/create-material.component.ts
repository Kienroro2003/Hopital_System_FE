import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-create-material',
  templateUrl: './create-material.component.html',
  styleUrls: ['./create-material.component.css']
})
export class CreateMaterialComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
