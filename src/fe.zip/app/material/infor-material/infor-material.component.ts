import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-infor-material',
  templateUrl: './infor-material.component.html',
  styleUrls: ['./infor-material.component.css']
})
export class InforMaterialComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
