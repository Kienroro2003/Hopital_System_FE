import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-import-manager',
  templateUrl: './import-manager.component.html',
  styleUrls: ['./import-manager.component.css']
})
export class ImportManagerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
