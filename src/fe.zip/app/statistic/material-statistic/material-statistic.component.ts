import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-material-statistic',
  templateUrl: './material-statistic.component.html',
  styleUrls: ['./material-statistic.component.css']
})
export class MaterialStatisticComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
