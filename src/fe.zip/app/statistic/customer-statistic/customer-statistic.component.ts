import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-customer-statistic',
  templateUrl: './customer-statistic.component.html',
  styleUrls: ['./customer-statistic.component.css']
})
export class CustomerStatisticComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
