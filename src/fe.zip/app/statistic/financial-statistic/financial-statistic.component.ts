import { Component, OnInit } from '@angular/core';
import {StatisticServiceService} from '../../service/statistic/statistic-service.service';
import {ICart} from '../../model/cart/icart';

@Component({
  selector: 'app-financial-statistic',
  templateUrl: './financial-statistic.component.html',
  styleUrls: ['./financial-statistic.component.css']
})
export class FinancialStatisticComponent implements OnInit {

  ban: number;
  tra: number;
  huy: number;
  luong: number;
  nhap: number;
  // statistic1: number;
  // tongthu = 0;
  constructor(private statisticService: StatisticServiceService) { }

  ngOnInit(): void {
    this.statisticService.getBan().subscribe(
      res => {
        this.ban = res;
        // this.tongthu = this.tongthu + this.statistic;
      });
    this.statisticService.getTra().subscribe(
      res => {
        this.tra = res;
        // this.tongthu = this.tongthu + this.statistic1;
      });
    this.statisticService.getHuy().subscribe(
      res => {
        this.huy = res;
        // this.tongthu = this.tongthu + this.statistic1;
      });
    this.statisticService.getLuong().subscribe(
      res => {
        console.log('1');
        this.luong = res;
        // this.tongthu = this.tongthu + this.statistic1;
      });
    this.statisticService.getNhap().subscribe(
      res => {
        console.log('1');
        this.nhap = res;
        // this.tongthu = this.tongthu + this.statistic1;
      });
  }
}
