import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sell-export',
  templateUrl: './sell-export.component.html',
  styleUrls: ['./sell-export.component.css']
})
export class SellExportComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
