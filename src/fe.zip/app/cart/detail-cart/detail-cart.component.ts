import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-detail-cart',
  templateUrl: './detail-cart.component.html',
  styleUrls: ['./detail-cart.component.css']
})
export class DetailCartComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
